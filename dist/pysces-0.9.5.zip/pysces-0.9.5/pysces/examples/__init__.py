"""
PySCeS - Python Simulator for Cellular Systems
           (http://pysces.sourceforge.net)
Copyright (C) B.G. Olivier, J.M. Rohwer, J.-H.S. Hofmeyr
Stellenbosch, 2004-2016.
Triple-J Group for Molecular Cell Physiology
Stellenbosch University, South Africa
Author: Brett G. Olivier

PySCeS is Open Source Software distributed under
the GNU GENERAL PUBLIC LICENSE (see docs/GPL)
"""

# Init file used for distutils install