This is an additional package that is distributed unchanged, with permission
from ZIB, under the terms of their own licence and warranty as described in nleq2.f
and *not* the PySCeS BSD style licence.

Please take careful notice of the usage conditions, licence  and warranty as
described in nleq2_readme.txt. If you do not agree with these usage conditions
you must either disable the installation of nleq2 or obtain a licence from ZIB.

To disable the co-installation of the nleq2 non-linear solver in
the user configuration section:

-- setup.py --
 # set
 nleq2 = 0

