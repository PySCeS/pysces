class test:
	def run(self):
		print '\nThis is a demonstration/template of a PySCeS user contributed extension'
		print '\nAdding a new extension module is a three step process:'
		print '========================================================'
		print '(1) create a directory which represents the name of\n     and contains your extension module.'
		print '(2) create a base module class in PyscesContribUser.py (CONTRIB_xxx)\n     see PyscesContrib.py for details.'
		print '(3) create an __init__.py file using the one in the demo\n     directory as a template that \
imports your extension module\n'
		print '\nThis is still rather experimental ... all comments welcome!\nBrett'
